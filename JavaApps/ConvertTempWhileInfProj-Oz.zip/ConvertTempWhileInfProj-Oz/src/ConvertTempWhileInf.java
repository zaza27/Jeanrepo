import java.util.Scanner;
 
/*
 * Write a program to convert degrees Fahrenheit
 * into degrees Celsius or reverse based on user
 * input choice, (i.e. integer result),
 * Use the formula
 *      C = (5.0/9.0) * (F-32.0)
 * Allow the user to specify how many numbers to convert.
 */
 
public class ConvertTempWhileInf {
 
    public static void main(String[] args) {
        char inputChoice = ' '; // We will use a char to get the choice
        String inputString = ""; // Temporarily read string to get char from
        String choiceString = "\nConvert to Celsius ('c') or Fahrenheit ('f')?";
        Scanner keyboard = new Scanner(System.in);
        String inputText = null;

        int degrees = 0;
        char switchOnChar = ' ';
        boolean leave =  false;
 
        
        while (!leave) {
        	System.out.println(choiceString);
            inputString = keyboard.next();
            inputChoice = inputString.charAt(0); 
            
            switchOnChar = inputChoice;
            
            switch (switchOnChar) {
            case 'c':
            case 'C':
                inputText = "\nEnter the degrees Fahrenheit (Integer value only): ";
                System.out.println(inputText);
                degrees = keyboard.nextInt();
                System.out.println(calculateCelsius(degrees));
                break;
            case 'f':
            case 'F':
                inputText = "\nEnter the degrees Celsius (Integer value only): ";
                System.out.println(inputText);
                degrees = keyboard.nextInt();
                System.out.println(calculateFahrenheit(degrees));
                break;
            case 'x':
            case 'X':
    		    leave = true;
            	break;
            default:
                System.out.println("\nUser must select 'c', 'C', 'f', 'F' or 'x' to exit");

                break;
            }
 
        }
        System.out.println("bye bye");
        keyboard.close();
    }
 
    private static String calculateCelsius(int fDegrees) {
        int cDegrees = 0;
        String midText = " Degrees Fahrenheit is ";
        String endText = " degrees Celsius.";
        String finalText = "";
 
        cDegrees = (int) ((5.0 / 9.0) * (fDegrees - 32.0));
        finalText = fDegrees + midText + cDegrees + endText;
        return finalText;
    }
 
    private static String calculateFahrenheit(int cDegrees) {
        int fDegrees = 0;
        String midText = " Degrees Celsius is ";
        String endText = " degrees Fahrenheit.";
        String finalText = "";
         
        fDegrees = (int) (cDegrees / (5.0 / 9.0)) + 32;
        finalText = cDegrees + midText + fDegrees + endText;
        return finalText;
    }
 
}