
public class BicycleClassDemo {

	public static void main(String[] args) {
		
	    System.out.println("We have " + Bicycle.getNumberOfBicycles() + " bicycles!");
	    
	    Bicycle bike1 = new Bicycle(5, 4, 3);
		System.out.format("BikeId: %d:: Cadence: %d, Speed: %d, Gear: %d%n"
				, bike1.getID(), bike1.getCadence()
				, bike1.getSpeed(), bike1.getGear());
		
		System.out.println("We have " + Bicycle.getNumberOfBicycles() + " bicycles!");
		Bicycle bikeB = new Bicycle(5, 4, 3);
		System.out.format("BikeId: %d:: Cadence: %d, Speed: %d, Gear: %d%n"
				, bikeB.getID(), bikeB.getCadence()
				, bikeB.getSpeed(), bikeB.getGear());
		System.out.println("We have " + Bicycle.getNumberOfBicycles() + " bicycles!");

	}

}
