import java.util.Scanner;

public class GuessingGame {

	public static void main(String[] args) {
		final String tooHigh = "You guess of %d is too high!";
		final String tooLow = "You guess of %d is too low!";
		final String prompt = "Guess a number between 1 and 100:";
		
		//Computer's guess
		final int guess = (int) ( Math.random() * 100 ) + 1;
		
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println(prompt);
		int userGuess = keyboard.nextInt();
		
		for (int chances = 0; chances < 6; chances++) {
			//if user guess = computer guess
			//then print you win!
			
			//if user guess < computer guess
			//then print tooLow!
			
			//if user guess < computer guess
			//then print tooHigh!
			
		}
		
		//You exited for loop so  print
		//Print Try Again.

	}

}
