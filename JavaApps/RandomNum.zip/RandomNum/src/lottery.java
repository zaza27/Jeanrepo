import java.util.Random;

public class lottery {

	public static void main(String[] args) {
		Random rnd = new Random();

		int n1 = 1 + rnd.nextInt(70 - 1);
		int n2 = 1 + rnd.nextInt(70 - 1);
		int n3 = 1 + rnd.nextInt(70 - 1);
		int n4 = 1 + rnd.nextInt(70 - 1);
		int n5 = 1 + rnd.nextInt(70 - 1);
		System.out.println("Luckys number is: " + n1 + " " + n2 + " " + n3 + " " + n4 + " " + n5);

		int n6 = 1 + rnd.nextInt(26 - 1);
		System.out.println("Mega Ball is: " + n6);

	}

}
