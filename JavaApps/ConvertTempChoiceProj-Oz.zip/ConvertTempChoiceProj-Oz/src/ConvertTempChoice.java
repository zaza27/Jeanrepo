import java.util.Scanner;

/*
 * Write a program to convert degrees Fahrenheit
 * into degrees Celsius or reverse based on user
 * input choice, (i.e. integer result),
 * Use the formula
 *      C = (5.0/9.0) * (F-32.0)
*/

public class ConvertTempChoice {

	public static void main(String[] args) {
		char inputChoice = ' '; // We will use a char to get the choice
		String inputString = ""; // Temporarily read string to get char from
		String choiceString = "Convert to Celsius ('c') or Fahrenheit ('f')?";
		Scanner keyboard = new Scanner(System.in);
		String inputText = "Enter the degrees Fahrenheit (Integer value only): ";
		int degrees = 0;

		// ***** New Code *****
		System.out.println(choiceString);
		inputString = keyboard.next();
		inputChoice = inputString.charAt(0); // see JavaDoc for String please
		if ((inputChoice == 'c') || (inputChoice == 'C')) {
			System.out.print(inputText);
			degrees = keyboard.nextInt();

			System.out.println();
			System.out.println(calculateCelsius(degrees) + "\n");
		} else if ((inputChoice == 'f') || (inputChoice == 'F')) {
			inputText = "Enter the degrees Celsius (Integer value only): ";
			System.out.print(inputText);
			degrees = keyboard.nextInt();

			System.out.println();
			System.out.println(calculateFahrenheit(degrees) + "\n");
		}

		keyboard.close();
	}

	private static String calculateCelsius(int fDegrees) {
		int cDegrees = 0;
		String midText = " Degrees Fahrenheit is ";
		String endText = " degrees Celsius.";
		String finalText = "";

		cDegrees = (int) ((5.0 / 9.0) * (fDegrees - 32.0));
		finalText = fDegrees + midText + cDegrees + endText;
		return finalText;
	}

	private static String calculateFahrenheit(int cDegrees) {
		int fDegrees = 0;
		String midText = " Degrees Celsius is ";
		String endText = " degrees Fahrenheit.";
		String finalText = "";

		// How I solved for fDegrees:
		// cDegrees = (int)((5.0/9.0) * ( fDegrees - 32.0 ));
		// cDegrees/(5.0/9.0) = ((5.0/9.0) * ( fDegrees - 32.0 ))/(5.0/9.0);
		// cDegrees/(5.0/9.0) = fDegrees - 32.0;
		fDegrees = (int) (cDegrees / (5.0 / 9.0)) + 32;
		finalText = cDegrees + midText + fDegrees + endText;
		return finalText;
	}

}