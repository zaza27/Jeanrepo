
public class BicycleAccessDemo {

	public static void main(String[] args) {
		Bicycle bike1 = new Bicycle(5,4,3);
		System.out.format("Cadence: %d, Speed: %d, Gear: %d%n",
		bike1.getCadence(), bike1.getSpeed(), bike1.getGear());
		bike1.setCadence(20);
		bike1.applyBrake(2);
		System.out.format("Cadence: %d, Speed: %d, Gear: %d%n",
				bike1.getCadence(), bike1.getSpeed(), bike1.getGear());
		
		Bicycle bike2 = new Bicycle();
		System.out.format("Cadence: %d, Speed: %d, Gear: %d%n",
				bike2.getCadence(), bike2.getSpeed(), bike2.getGear());
		bike2.speedUp(15);
		bike2.setGear(6);
		System.out.format("Cadence: %d, Speed: %d, Gear: %d%n",
				bike2.getCadence(), bike2.getSpeed(), bike2.getGear());
		
	}

}
