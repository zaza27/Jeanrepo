
public class MockBetterBicycle implements BetterBicycle {

	@Override
	public void changeCadence(int newValue) {
	}

	@Override
	public void changeGear(int newValue) {
	}

	@Override
	public void speedUp(int increment) {
	}

	@Override
	public void applyBrakes(int decrement) {
	}

	@Override
	public void printStates() {
		System.out.println("I'm ready to test!");
	}	

}
