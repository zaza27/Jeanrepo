import java.util.Scanner;
 
// OLD ConvertTempWhileInf.java CODE TO BE UPDATED FOR ConvertTempObject.java
 
/*
 * Write a program to convert degrees Fahrenheit
 * into degrees Celsius or reverse based on user
 * input choice, (i.e. integer result),
 * Use the formula
 *      C = (5.0/9.0) * (F-32.0)
 * Exit when the user enters x
*/
 
public class ConvertTempObject {
 
    public static void main(String[] args) {
    	Temperature temp1 = new Temperature();
    	
    	temp1.printState();
    	
    	temp1.setDegrees(32);
    	temp1.setScale('f');
    	
    	temp1.printState();
    	
    	Temperature temp2 = new Temperature();
    	temp2.setDegrees(100.0);
    	temp2.setScale('c');
    	
    	temp2.printState();
    	
    	Temperature temp3 = temp2.convert();
    	System.out.print("is ");
    	
    	temp3.printState();
    	
    	
//        char inputChoice = ' '; // We will use a char to get the choice
//        String inputString = ""; // Temporarily read string to get char from
//        String choiceString = "\nConvert to Celsius ('c') or Fahrenheit ('f')?";
//        Scanner keyboard = new Scanner(System.in);
//        String inputText = "Enter the degrees Fahrenheit (Integer value only): ";
//        int degrees = 0;
//        char switchOnChar = ' ';
// 
//        while (true) {
// 
//            System.out.println(choiceString);
//            inputString = keyboard.next();
//            inputChoice = inputString.charAt(0); // see JavaDoc for String
//                                                    // please
// 
//            switchOnChar = inputChoice;
// 
//            switch (switchOnChar) {
//            case 'c':
//            case 'C':
//                System.out.println("\n" + inputText);
//                degrees = keyboard.nextInt();
//                System.out.println(calculateCelsius(degrees));;
//                break;
//            case 'f':
//            case 'F':
//                inputText = "\nEnter the degrees Celsius (Integer value only): ";
//                System.out.println(inputText);
//                degrees = keyboard.nextInt();
//                System.out.println(calculateFahrenheit(degrees));
//                break;
//            case 'x':
//                break;
//            default:
//                System.out.println("User must select 'c', 'C', 'f', 'F', or 'x' to exit.");
//                break;
//            }
//            if (switchOnChar == 'x' ) {
//                System.out.println("\nBye Bye");
//                break;
//            }
// 
//        }
// 
//        keyboard.close();
    }
 
    
}