public class Temperature {
	double degrees;
	char scale;
	
	void setDegrees(double deg) {
		degrees = deg;
	}
	
	void setScale(char s) {
		scale = s;
	}
	
	Temperature convert() {
		Temperature result;
		if (scale == 'c') {
			result = calculateFahrenheit();
		} else {
			result = calculateCelsius();
		}
		return result;
	}
	
	private Temperature calculateCelsius() {
		Temperature result = new Temperature();
		result.scale = 'c';
        result.degrees = ((5.0 / 9.0) * (degrees - 32.0));
        return result;
    }
 
    private Temperature calculateFahrenheit() {
    	Temperature result = new Temperature();
    	result.scale = 'f';
        result.degrees = (degrees / (5.0 / 9.0)) + 32;
        return result;
    }
    
	void printState() {
//		System.out.format("%3.2f Degrees %s"
//				, degrees, scale=='c'?"Celsius":"Fahrenheit");
		String scaleText;
		if (scale == 'c') {
			scaleText = "Celsius";
		} else {
			scaleText = "Fahrenheit";
		}
		System.out.format("%3.2f Degrees %s%n", degrees, scaleText);
	}
 
}