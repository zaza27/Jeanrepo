class MountainBikeDemo {
    public static void main(String[] args) {
  
        // Create two different 
        // Bicycle objects
        Bicycle bike1 = new MountainBike(5,4,3,2);
        Bicycle bike2 = new MountainBike(15,14,13,12);
        // Invoke methods on 
        // those objects
        bike1.setCadence(50);
        bike1.speedUp(10);
        bike1.setGear(2);
        System.out.format("Cadence: %d, Gear: %d, Speed: %d, Height: %d%n",
        		bike1.cadence, bike1.gear, bike1.speed
        		, ((MountainBike)bike1).seatHeight);

  
        bike2.setCadence(50);
        bike2.speedUp(10);
        bike2.setGear(2);
        bike2.setCadence(40);
        bike2.speedUp(10);
        bike2.setGear(3);
        bike2.applyBrake(2);
        System.out.format("Cadence: %d, Gear: %d, Speed: %d, Height: %d%n",
        		bike2.cadence, bike2.gear, bike2.speed
        		, ((MountainBike)bike2).seatHeight);

    }
}